﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace waitingForm
{
    public partial class Form1 : Form
    {
        public bool ExitWaitingForm = false;
        public string TipForWaitingForm = "";
        public Form1()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            ExitWaitingForm = false;
            TipForWaitingForm = "环境正在检测中。。。";
            Form2 wf = new Form2();
            wf.ShowDialog();
            wf.Dispose();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //ExitWaitingForm = false;
            //TipForWaitingForm = "环境正在检测中。。。";
            //Form2 wf = new Form2(this );
            //wf.ShowDialog();
            
        }
    }
}
